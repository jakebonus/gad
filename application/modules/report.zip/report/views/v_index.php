        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Reports</h2>
                    <div class="clearfix"></div>
                  </div>
                  <form id="frm_sdispense" autocomplete="off" method="post" class="fv-form fv-form-bootstrap">
                    <input type="hidden" class="" id="tr_qty1" name="tr_qty1">

                    <div class="row">
                      <div class="form-group col-md-3 col-sm-3 col-xs-6">
                        <label class="control-label">Format <span>*</span></label>
                        <select class="form-control input-sm" id="tr_format" name="tr_format" required="">
                          <option value="">- - -</option>
                          <option value="0">Dosage Form</option>
                          <option value="1">Therapeutic Use</option>
                        </select>
                      </div>
                    </div>

                    <div class="row">
                     <div class="form-group col-md-3 col-sm-4 col-xs-6">
                       <label class="control-label">Source</label>
                       <select class="form-control input-sm" id="tr_location" name="tr_location">
                         <option value="">- - -</option>
                       </select>
                     </div>
                     <div class="form-group col-md-3 col-sm-4 col-xs-6">
                      <label class="control-label">Fund</label>
                      <select class="form-control input-sm" id="tr_funding" name="tr_funding">
                        <option value="">- - -</option>
                      </select>
                    </div>
                    <div class="form-group col-md-4 col-sm-4 col-xs-6">
                     <label class="control-label">Form - To</label>
                     <div class="input-daterange" id="datepicker" >
                       <input type="text" class="date form-control1 input-sm col-md-5 col-sm-5 col-xs-5" name="start" />
                       <span class="add-on col-md-2 col-sm-2 col-xs-2" style="vertical-align: top;height:20px">to</span>
                       <input type="text" class="date form-control1 input-sm col-md-5 col-sm-5 col-xs-5" name="end" />
                     </div>
                   </div>
                 </div>

                 <div class="actionBar">
                  <button type="button" id="btn_cancel" class="buttonFinish btn btn-default">Cancel</button>
                  <button type="submit" id="btn_search" class="btn btn-success">Search</button>
                </div>

              </form>

              <button onclick="printContent('report-datatable')" type="button" class="hidden btn btn-primary _print">Print</button>
        <!--       <table class="hidden cell-border compact hover width-full" id="dt_report" cellspacing="0" width="100%">
               <thead>
                <tr>
                  <th>MEDICINE</th>
                  <th style="min-width: 90px;">FUND</th>
                  <th style="min-width: 90px;">LOCATION</th>
                  <th style="min-width: 90px;">m_therapeutic_use</th>
                  <th style="min-width: 90px;">m_dosage_form</th>
                  <th style="min-width: 90px;">tr_date</th>
                  <th>AVAILABLE</th>
                  <th>REMARKS</th>
                </tr>
              </thead>
            </table> -->
            <div id="report-datatable">
            <table id="report-dt" class="hidden cell-border compact hover width-full">
                <thead>
                  <tr></tr>
                </thead>
                <tfoot>
                  <tr>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                  </tr>
                </tfoot>
              </table>
            </div>

          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- /page content -->
