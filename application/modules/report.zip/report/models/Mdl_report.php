<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Mdl_report extends CI_Model {

	public function __construct() {
		parent::__construct();
	}

	public function m_ajax_get_report($data) {

		$tr_location = $data['tr_location'];
		$tr_funding = $data['tr_funding'];
		$start = $data['start'];
		$end = $data['end'];

		$sql = "SELECT 
				  `m`.`m_id`,
				   CONCAT(`m`.`m_name`,' ',LOWER(`m`.`m_dosage_form`)) AS `m_name`,
				  `m`.`m_therapeutic_use`,
				  `m`.`m_dosage_form`,
				  `t`.`tr_funding`,
				  `t`.`tr_location`,
				  `t`.`tr_date`,
				  `m`.`m_set`,
				  `m`.`m_pcsper_set`,
				SUM(`t`.`tr_qty` * `t`.`tr_pcsper_set`) AS `pcsper_set_x_qty`,
				FLOOR(SUM(`t`.`tr_qty` * `t`.`tr_pcsper_set`) / `m`.`m_pcsper_set`) AS `box`,
				SUM(`t`.`tr_qty` * `t`.`tr_pcsper_set`) -(FLOOR(SUM(`t`.`tr_qty` * `t`.`tr_pcsper_set`) / `m`.`m_pcsper_set`)*`m`.`m_pcsper_set`) AS `pcs`
				FROM
				  `tbl_transaction` `t` 
				  LEFT JOIN `tbl_medicine` `m` 
				    ON `m`.`m_id` = `t`.`tr_m_id` 
				WHERE `t`.`tr_isdeleted` = '1'";

		if ($tr_location != '') {
			$sql .="AND `t`.`tr_location` = '".$tr_location."'";
		}
		if ($tr_funding != '') {
			$sql .="AND `t`.`tr_funding` = '".$tr_funding."'";
		}

		if ($start != '' || $end != '') {
			$sql .="AND `t`.`tr_date` BETWEEN CAST('".$start."' AS DATE) AND CAST('".$end."' AS DATE)";
		}

		$sql .= "GROUP BY `t`.`tr_m_id` HAVING SUM(`t`.`tr_qty` * `t`.`tr_pcsper_set`) > 0";

        $query = $this->db->query($sql);
        if ($query->num_rows() > 0) {
            return $query->result();
        } else {
            return false;
        }
	}

   
}
