<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Report extends MX_Controller
{
    //============ CONSTRUCTOR
    public function __construct()
    {
        parent::__construct();
        $this->load->model('mdl_report');
    }

    public function index() {
		if ($this->session->userdata('accountId')) {
			$data['title'] = 'Report';
            $data['content'] = 'report/v_index';
            $this->load->view('layouts/v_master', $data);
		 } else {
			redirect('/');
		}
    }

    public function ajax_get_report() {
        if ($this->session->userdata('accountId')) {
            $data['tr_location'] = $this->input->post('tr_location');
            $data['tr_funding'] = $this->input->post('tr_funding');
            $data['start'] = $this->input->post('start');
            $data['end'] = $this->input->post('end');

            if($this->mdl_report->m_ajax_get_report($data))
            {
                $result = $this->mdl_report->m_ajax_get_report($data);
                echo json_encode($result);
            } else {
                $result = array('status' => 'no','content'=> 'Failed to search medicine. Please try again!');
                echo json_encode($result);
            }
        } else {
            redirect('/');
        }
    }
}
