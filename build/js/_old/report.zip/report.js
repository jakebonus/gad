$(function() {
    var tablea = null;
    $(".date").inputmask("9999-99-99",{ "placeholder": "yyyy-mm-dd" });
    $('.input-daterange').datepicker({
        todayBtn: "linked",
        format: 'yyyy-mm-dd',
    });

    //GET LOCATION FROM TR_TRANSACTION
    $.getJSON(base_url + "admin/ajax_get_tr_location", function(data) {
        $("#tr_location option").detach();
        $("#tr_location").append('<option value="">- - -</option>');
        $.each(data, function(index, item) {
            $("#tr_location").append("<option class=" + index + ">" + item.tr_location + "</option>");
            var a = "#tr_location option." + index;
            $(a).attr("value", item.tr_location);
        });
    });

    //GET LOCATION FROM tr_funding
    $.getJSON(base_url + "admin/ajax_get_tr_funding", function(data) {
        $("#tr_funding option").detach();
        $("#tr_funding").append('<option value="">- - -</option>');
        $.each(data, function(index, item) {
            $("#tr_funding").append("<option class=" + index + ">" + item.tr_funding + "</option>");
            var a = "#tr_funding option." + index;
            $(a).attr("value", item.tr_funding);
        });
    });

    $('#frm_sdispense').formValidation({
        framework: "bootstrap",
        button: {
            selector: '#btn_search',
            disabled: 'disabled'
        },
        icon: null,

    })
    .on('success.form.fv', function(e) {
        e.preventDefault();
        var $form = $(e.target),
        fv = $form.data('formValidation');

        var url = base_url + "report/ajax_get_report",
        data = $("#frm_sdispense").serializeObject();
        otable(url,data);
        $form.data('formValidation').disableSubmitButtons(false);
        return false;
    });

    function otable(url,data) {
        $("#report-dt, ._print").removeClass("hidden");
        var f = $("#tr_format").val();

        $('#report-datatable').empty();
        $('#report-datatable').append('<table id="report-dt" class="cell-border compact hover width-full">' +
            '<thead>' +
                '<tr></tr>' +
            '</thead>' +
            '<tfoot>' +
                '<tr>' +
                    '<th></th>' +
                    '<th></th>' +
                    '<th></th>' +
                    '<th></th>' +
                    '<th></th>' +
                    '<th></th>' +
                    '<th></th>' +
                    '<th></th>' +
                    '<th></th>' +
                '</tr>' +
            '</tfoot>' +
        '</table>');

         tablea = $('#report-dt').DataTable({
            'ajax': {
                'type': "POST",
                'url': url,
                'data': data,
                'dataSrc': ""
            },
            'columns': [
                {
                    "title": "m_therapeutic_use",
                    "data": "m_therapeutic_use"
                    // "visible": false
                }, {
                    "title": "MEDICINE",
                    "data": function(data) {
                        return data.m_name + '[' + data.m_pcsper_set + ']';
                   },
                    "sortable": false
                }, {
                    "title": "m_dosage_form",
                    "data": "m_dosage_form",
                    "sortable": false
                }, {
                    "title": "tr_funding",
                    "data": "tr_funding",
                    "sortable": false
                }, {
                    "title": "tr_date",
                    "data": "tr_date",
                    "sortable": false
                }, {
                    "title": "REMARKS",
                    "data": function(data) {
                        return get_txt_box(data.box,data.m_set) + ' ' + get_txt_pcs(data.box,data.pcs);
                    },                    "sortable": false
                }, {
                    "title": "m_pcsper_set",
                    "data": "m_pcsper_set",
                    "sortable": false
                }, {
                    "title": "AVAILABLE",
                     "data": function(data) {
                        return data.pcsper_set_x_qty + ' PCS';
                    },
                    "sortable": false
                }, {
                    "title": "box",
                    "data": "box",
                    "sortable": false
                }
                , {
                    "title": "pcs",
                    "data": "pcs",
                    "sortable": false
                }
            ],
            scrollY: 220,
            'order': [[ get_format(f,1), "asc" ]], //3- dosage_)form, 1-therapeutic
            'dom': '<"wrapper"fit>',
            'bFilter': false,
            'info': false,
            'columnDefs': [
                { "visible": false, "targets": [0,2,3,4,6,8,9] }
            ],
            'drawCallback': function (settings) {
                var api = this.api();
                var rows = api.rows({
                    page: 'current'
                }).nodes();
                var last = null;
                api.column(get_format(f,0), { //2- dosage_form, 0-therapeutic
                    page: 'current'
                }).data().each(function (group, i) {
                    if (last !== group) {
                        $(rows).eq(i).before(
                        $("<tr></tr>", {
                            "class": "group",
                            "data-id": group
                        }).append($("<td></td>", {
                            "colspan": 2,
                            "class": "pocell",
                            "text": "" + group
                        })).append($("<td></td>", {
                            "id": "p" + group,
                            "class": "noCount",
                            "text": "0"
                        })).prop('outerHTML'));
                        last = group;
                    }
                    val = api.row(api.row($(rows).eq(i)).index()).data();
                   
                    if (f == 0) {
                        $("#p" + val.m_dosage_form).text(parseFloat($("#p" + val.m_dosage_form).text()) + parseFloat(val.pcsper_set_x_qty) + " PCS");
                    } else {
                         $("#p" + val.m_therapeutic_use).text(parseFloat($("#p" + val.m_therapeutic_use).text()) + parseFloat(val.pcsper_set_x_qty) + " PCS");
                    }
                });
            }
        });

    }


    function get_txt_pcs(str1,str) {
        var txt = '', txt2 = '';
        if (str1 > 0) { txt2 = 'and'; }

        if (str > 1) {
            txt = txt2 + ' ' + str + ' PCS';
        } else {
            if (str > 0) { txt = txt2 + ' ' + str + ' PC'; }
        }
        return txt;
    }

    function get_txt_box(str,str1) {
        var txt = '';
        if (str > 1) {
            txt = str + ' ' + str1 + 'ES';
        } else {
            if (str > 0) { txt = str + ' ' + str1; }
        }
        return txt;
    }

    function get_format(val,tri) {
        var txt = 0;
        if (val == 0) {
            txt = 2 + Number(tri);
        } else {
            txt = 0 + Number(tri);
        }
        return txt;
    }

    //FORM OBJECT
    $.fn.serializeObject = function()
    {
       var o = {};
       var a = this.serializeArray();
       $.each(a, function() {
           if (o[this.name]) {
               if (!o[this.name].push) {
                   o[this.name] = [o[this.name]];
               }
               o[this.name].push(this.value || '');
           } else {
               o[this.name] = this.value || '';
           }
       });
       return o;
    };


});

    function printContent(el){
        var divToPrint=document.getElementById(el);
            newWin= window.open("");
            newWin.document.write('<html><head><style>.dataTables_scrollBody,.dataTables_scrollHead,#report-dt{width:auto!important;height:auto!important;;overflow:visible!important;}table {border-collapse:collapse;}table td, table th{ border: 1px solid black; text-align:left;} tr.group{background-color: #d8d8d8;margin-top:10px;padding-top:10px}</style>');
            newWin.document.write('</head><body onload="window.print()">');
            newWin.document.write(divToPrint.outerHTML);
            newWin.document.write('</body>');
            newWin.document.write('</html>');
            newWin.print();
            newWin.close();
    }

